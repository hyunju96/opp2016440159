
public class Test {
	public static void main(String[] args) {
		Student you = new Student(24, "Jung Mi Su");
		
		//you.age = 18;
		you.printage();
		you.printname();
	}
}
